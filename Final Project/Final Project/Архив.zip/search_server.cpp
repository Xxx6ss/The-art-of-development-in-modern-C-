//
//  search_server.cpp
//  Final Project
//
//  Created by Andrew Kireev on 19.06.2020.
//  Copyright © 2020 Andrew Kireev. All rights reserved.
//

#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <numeric>



vector<string> SplitIntoWords(const string& line) {
  istringstream words_input(line);
  return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
  UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
  InvertedIndex new_index;

    new_index.Add(document_input);

    index = new_index;
}


//0 1
//
//0 1
//docid: 0, hitcount: 1
//0 1
//1 1
//
//0 1
//1 1
//docid: 0, hitcount: 1
//docid: 1, hitcount: 1


void SearchServer::AddQueriesStream(
  istream& query_input, ostream& search_results_output
) {
    
    auto& documents = index.GetDocument();
    vector<size_t> v(documents.size());
    vector<size_t> docid_count(documents.size());
     v.reserve(50'000);
  for (string current_query; getline(query_input, current_query); ) {
    auto words = SplitIntoWords(current_query);

    docid_count.assign(docid_count.size(), 0);
      
    for (string& word : words) {
        auto con = index.Lookup(word);
        for (const auto& [docid, rating] : con) {
          docid_count[docid] += rating;
      }
    }
//      vector<pair<size_t, size_t>> search_results;
//      for (size_t i = 0; i < v.size(); ++i) {
//          if (v[i] != 0)
//              search_results.push_back({i, v[i]});
//      }
      
      
      iota(v.begin(), v.end(), 0);
      
    partial_sort(
      begin(v),
         Head(v, 5).end(),
         end(v),
      [&docid_count](int64_t lhs, int64_t rhs) {
          return make_pair(docid_count[lhs], -lhs) > make_pair(docid_count[rhs], -rhs);
      }
      );

    search_results_output << current_query << ':';
    for (size_t docid : Head(v, 5)) {
        
        size_t hitcount = docid_count[docid];
        
        if (hitcount == 0) {
            break;
        }
        
      search_results_output << " {"
        << "docid: " << docid << ", "
        << "hitcount: " << hitcount << '}';
        
//        cout << "docid: " << docid << ", "
//        << "hitcount: " << hitcount << endl;
    }
      
    search_results_output << endl;
  }
}




void InvertedIndex::Add(istream& documents) {
    for(string document; getline(documents, document); ){
    
  docs.push_back(document);

  const size_t docid = docs.size() - 1;
        auto con = SplitIntoWords(document);
  for (auto word : con) {
      
      auto& docids = index[word];
      
      if (!docids.empty() && docids.back().doc_id_==docid ) {
          docids.back().rating_++;
      } else {
          docids.push_back({docid, 1});
      }
  }
    }
}

vector<InvertedIndex::DocRating> InvertedIndex::Lookup(string& word) const {
  if (auto it = index.find(word); it != index.end()) {
    return it->second;
  } else {
    return {};
  }
}

